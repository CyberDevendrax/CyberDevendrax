# How to add data for a new version ?

## Protocol

Follow https://wiki.vg/Pre-release_protocol

## Blocks, Items, Entities, Recipes

use https://github.com/PrismarineJS/burger-extractor

## Block collison shape 

https://github.com/PrismarineJS/minecraft-data/blob/master/doc/blockCollisionShapes.md#data-source

## Loot table

https://github.com/PrismarineJS/minecraft-jar-extractor#block-loot-table-extractor

## WIP

This guide is WIP, more information will be added here


If something doesn't work, look at the list of extractors for ideas https://github.com/PrismarineJS/minecraft-data#extraction
